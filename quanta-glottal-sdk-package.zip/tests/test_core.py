from qg_sdk.core import QuantaGlottalSDK

def test_process_signal():
    sdk = QuantaGlottalSDK()
    assert "Signal traité" in sdk.process_signal("exemple")
