from qg_sdk.core import QuantaGlottalSDK

sdk = QuantaGlottalSDK()
print(sdk.process_signal("signal_demo"))
